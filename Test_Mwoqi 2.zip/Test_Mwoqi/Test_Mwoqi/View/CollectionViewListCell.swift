//
//  CollectionViewListCell.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/16.
//

import UIKit
import SnapKit
import RxSwift

typealias DidLikeBlock = (_ indexPath: IndexPath?) -> Void

class CollectionViewListCell: UICollectionViewCell {
    static let reuseIdentifier = String(describing: self)
    var disposeBag = DisposeBag()
    var index_path: IndexPath!
    public var likeBlock: DidLikeBlock?

    override init(frame: CGRect) {
        super.init(frame: frame)
        createContentView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func createContentView() {
        contentView.addSubview(likeImageButton)
        contentView.addSubview(titleLabel)
        contentView.addSubview(bodyLabel)

        likeImageButton.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(25)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(likeImageButton.snp_bottomMargin).offset(10)
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        bodyLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp_bottomMargin).offset(10)
            make.bottom.equalToSuperview().offset(-10)
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        self.likeImageButton.rx.tap.subscribe { [weak self] _event in
            self?.buttonClick()
        }.disposed(by: disposeBag)
    }
    
    @objc func buttonClick() {
        self.likeBlock!(self.index_path)
    }
    
    public func setDataModel(_ model: FirstListRepository?, _ indexPath: IndexPath) {
        self.index_path = indexPath
        var likeImage = UIImage.init(named: "icons_like_enabled")
        if model?.like == nil || model?.like == false {
            likeImage = UIImage.init(named: "icons_like_enabled") 
        } else {
            likeImage = UIImage.init(named: "icons_like_selected")
        }
        
        self.likeImageButton.setImage(likeImage, for: .normal)
        self.titleLabel.text = "\(model?.title ?? "")"
        self.bodyLabel.text = "\(model?.body ?? "")"
    }

    // MARK: - Lazy Loading
    public lazy var likeImageButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = NSTextAlignment.left
        label.font = UIFont.boldSystemFont(ofSize: 15)
        label.textColor = UIColor.black
        return label
    }()
    
    private lazy var bodyLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = NSTextAlignment.left
        label.font = UIFont.systemFont(ofSize: 12)
        label.textColor = UIColor.black
        return label
    }()
}
