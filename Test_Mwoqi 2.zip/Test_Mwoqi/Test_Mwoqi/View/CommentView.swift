//
//  CommentView.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/17.
//

import UIKit

class CommentView: UIView {
    public func initUI() {
        self.backgroundColor = UIColor.white
        self.addSubview(likeImageButton)
        self.addSubview(tableView)
        
        likeImageButton.snp.makeConstraints { (make) in
            make.top.equalTo(self).offset(100)
            make.centerX.equalTo(self)
            make.width.height.equalTo(60)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(likeImageButton.snp_bottomMargin).offset(20)
            make.bottom.equalToSuperview()
            make.centerX.equalTo(self)
            make.width.equalToSuperview()
        }
    }
    
    func showLikeView(_ status: Bool) {
        let likeImage = status ? UIImage.init(named: "icons_like_selected") : UIImage.init(named: "icons_like_enabled")
        self.likeImageButton.setImage(likeImage, for: .normal)
    }
    
    // MARK: - Lazy Loading
    public lazy var likeImageButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    public lazy var tableView: UITableView = {
        () -> UITableView in
        let tableView = UITableView.init(frame: self.frame)
        tableView.backgroundColor = UIColor.white
        tableView.rowHeight = 49

        return tableView;
    }()
}
