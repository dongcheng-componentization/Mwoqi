//
//  TableViewCommentCell.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/18.
//

import UIKit

class TableViewCommentCell: UITableViewCell {
    static let reuseIdentifier = String(describing: self)

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = UITableViewCell.SelectionStyle.none
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        initUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) not implemented yet")
    }
    
    public func initUI() {
        self.backgroundColor = UIColor.white
        self.addSubview(likeImageView)
        self.addSubview(nameLabel)
        self.addSubview(emailLabel)
        self.addSubview(bodyLabel)

        likeImageView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.height.equalTo(25)
        }

        nameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(likeImageView.snp_bottomMargin).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(self)
        }
        
        emailLabel.snp.makeConstraints { (make) in
            make.top.equalTo(nameLabel.snp_bottomMargin).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(self)
        }

        bodyLabel.snp.makeConstraints { (make) in
            make.top.equalTo(emailLabel.snp_bottomMargin).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.equalToSuperview()
        }
    }
    
    public func setDataModel(_ model: CommentDetailRepository?, _ index: Int) {
//        let likeImage = model?.like ?? true ?
//            UIImage.init(named: "icons_like_enabled") :
//            UIImage.init(named: "icons_like_selected")
//        self.likeImageButton.setImage(likeImage, for: .normal)
        self.nameLabel.text = "\(model?.name ?? "")"
        self.emailLabel.text = "\(model?.email ?? "")"
        self.bodyLabel.text = "\(model?.body ?? "")"
    }
    
    // MARK: - Lazy Loading
    public lazy var likeImageView: UIImageView = {
        let image = UIImageView()
        return image
    }()
    
    public lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = NSTextAlignment.center
        label.font = UIFont.systemFont(ofSize: 15)
        label.textColor = UIColor.black
        return label
    }()
    
    public lazy var emailLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = NSTextAlignment.center
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.darkGray
        return label
    }()
    
    public lazy var bodyLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = NSTextAlignment.center
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = UIColor.darkGray
        return label
    }()

}
