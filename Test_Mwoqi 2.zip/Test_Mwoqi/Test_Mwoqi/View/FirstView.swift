//
//  FirstView.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/16.
//

import UIKit

class FirstView: UIView {
    
    public func initUI() {
        self.backgroundColor = UIColor.white
        self.addSubview(collectionView)

    }
    
    
    // MARK: - Lazy Loading
    private lazy var collectionViewLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        let spacing: CGFloat = 0
        let numOfColumns: CGFloat = 2.0
        let itemWidth: CGFloat = (UIScreen.main.bounds.width) / numOfColumns - 2
        layout.itemSize = CGSize(width: itemWidth, height: 150)
        layout.minimumInteritemSpacing = spacing
        layout.minimumLineSpacing = 2
        layout.sectionInset = UIEdgeInsets(top: spacing, left: spacing, bottom: spacing, right: spacing)
        return layout
    }()
    
    public lazy var collectionView: UICollectionView = {
        () -> UICollectionView in
        let collection = UICollectionView.init(frame: self.frame, collectionViewLayout: collectionViewLayout)
        collection.backgroundColor = UIColor.white
        return collection;
    }()
}
