//
//  ViewController.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/14.
//

import UIKit
import RxSwift
import RxDataSources
import RxCocoa
//import UQToastView

class FirstViewController: UIViewController, UIScrollViewDelegate {
    private let disposeBag = DisposeBag()
    var viewModel = FirstViewModel()
    var firstView = FirstView()

    @IBOutlet weak var sortedItem: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self .createUI()
        self.viewModel.loadData()
        //注册cell
        registryCollectionView()
        //绑定数据
        rxBind()
    }
    
    func createUI() {
        self.view.backgroundColor = UIColor.white
        self.title = "列表页"
        self.firstView.frame = self.view.frame
        if let view = self.view as? FirstView {
            self.firstView = view
        } else {
            self.view = self.firstView
            self.view.backgroundColor = UIColor.white
        }
        
        self.firstView.initUI()
    }
    
    func registryCollectionView() {
        self.firstView.collectionView.register(CollectionViewListCell.self, forCellWithReuseIdentifier: CollectionViewListCell.reuseIdentifier)
    }
    
    func rxBind() {
        let listReloadData = RxCollectionViewSectionedReloadDataSource<SectionModel<String, FirstListRepository>> { [self] data, collectionView, indexPath, model ->
            UICollectionViewCell in

            let cell = collectionView.dequeueReusableCell(
                withReuseIdentifier: CollectionViewListCell.reuseIdentifier,
                for: indexPath,
                cellType: CollectionViewListCell.self
            )
            cell.backgroundColor = UIColor.red.withAlphaComponent(0.2)
            cell.setDataModel(model, indexPath)
            cell.likeBlock = { indexPath in
                viewModel.writeFirstData(indexPath!)
            }
            return cell
        }
        
        self.firstView.collectionView.rx.modelSelected(FirstListRepository.self).subscribe { (event) in
            let commentVC = CommentViewController()
            commentVC.viewModel.like = event.element?.like
            commentVC.viewModel.id = event.element?.id ?? 1
            commentVC.viewModel.userId = event.element?.userId ?? 1
            commentVC.viewModel.rxLikeStatus.onNext(event.element?.like ?? false)
            
            commentVC.didBlock = { (userId) in
                // 根据回执数据可更改列表 
            }
            self.navigationController?.pushViewController(commentVC, animated: true)
          
            
        }.disposed(by: disposeBag)
        
        viewModel.rxFirstData.bind(to: firstView.collectionView.rx.items(dataSource: listReloadData)).disposed(by: disposeBag)
        firstView.collectionView.rx.setDelegate(self).disposed(by: disposeBag)
        
        viewModel.rxSortedStatus.subscribe(onNext: { [self] status in
            if status {
                self.sortedItem.title = "排序↑"
            } else {
                self.sortedItem.title = "排序↓"
            }
        }).disposed(by: disposeBag)
        
        // 请求数据error
        viewModel.rxRequestError.subscribe(onNext: { [weak self] error in
            let msg = "请求数据error \(error)"
            let dialog = UQToastView.toastInit(content: msg, type: "error")
            dialog?.show(superView: (self?.view)!)
        }).disposed(by: disposeBag)
    }
    
    @IBAction func loadDataMore(_ sender: UIBarButtonItem) {
        viewModel.loadData()
    }
    
    @IBAction func sort(_ sender: UIBarButtonItem) {
        viewModel.sorted()
    }
}
