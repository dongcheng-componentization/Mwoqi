//
//  CommentViewController.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/17.
//

import UIKit
import RxSwift
import RxCocoa

typealias DidLikeButtonBlock = (_ userId: Int?) -> Void

class CommentViewController: UIViewController {
    private let disposeBag = DisposeBag()
    public var didBlock: DidLikeButtonBlock?

    var viewModel = CommentViewModel()
    var commentView = CommentView()

    override func viewDidLoad() {
        super.viewDidLoad()
        createUI()
        // 加载网络数据
        self.viewModel.loadData()
        //绑定数据
        registerCell()
        rxBind()
    }
    
    func createUI() {
        self.view.backgroundColor = UIColor.white
        self.title = "详情页"
        self.commentView.frame = self.view.frame
        if let view = self.view as? CommentView {
            self.commentView = view
        } else {
            self.view = self.commentView
            self.view.backgroundColor = UIColor.white
        }
        // 初始化UI
        self.commentView.initUI()
    }
    
    func registerCell() {
        commentView.tableView.register(TableViewCommentCell.self, forCellReuseIdentifier: TableViewCommentCell.reuseIdentifier)
    }
    
    func rxBind() {
        viewModel.rxCommentData.bind(to: commentView.tableView.rx.items(cellIdentifier: TableViewCommentCell.reuseIdentifier)){ row, model, cell in
            if let view = cell as? TableViewCommentCell {
                view.setDataModel(model, row)
            }
            
        }.disposed(by: disposeBag)
        commentView.tableView.rx.setDelegate(self).disposed(by: disposeBag)
        
        commentView.likeImageButton.rx.tap.subscribe { [weak self] (model) in
            //这个可更改上个页面数据
            self?.didBlock!(self?.viewModel.userId)
        }.disposed(by: disposeBag)
        
        // 请求数据error
        viewModel.rxRequestError.subscribe(onNext: { [weak self] error in
            let msg = "请求数据error \(error)"
            let dialog = UQToastView.toastInit(content: msg, type: "error")
            dialog?.show(superView: (self?.view)!)
        }).disposed(by: disposeBag)
        
        viewModel.rxLikeStatus.subscribe(onNext: { [self] in
            self.commentView.showLikeView($0)
        }).disposed(by: disposeBag)
    }
}

extension CommentViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
