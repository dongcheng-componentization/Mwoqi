//
//  FirstResponseDTO.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/16.
//

import Foundation
import HandyJSON

//class FirstListRepository: HandyJSON {
//    public var title: String?
//    public var userId: Int?
//    public var id: String?
//    public var body: String?
//    public var like: Bool?
//
//    required public init() {}
//}

public struct FirstListRepository: Codable {
    public var title: String?
    public var userId: Int?
    public var id: Int?
    public var body: String?
    public var like: Bool?
}
