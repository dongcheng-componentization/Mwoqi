//
//  CommentResponseDTO.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/17.
//

import UIKit

public struct CommentDetailRepository: Codable {
//    public var like: Bool?
    public var postId: Int?
    public var id: Int?
    public var name: String?
    public var email: String?
    public var body: String?

}
