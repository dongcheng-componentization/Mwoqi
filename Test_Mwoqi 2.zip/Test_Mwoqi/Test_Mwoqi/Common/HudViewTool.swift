//  Copyright © 2020 Fast Retailing Co., Ltd. All rights reserved.
//

import UIKit

class HudViewTool: NSObject {
    let keyWindow = UIApplication.shared.keyWindow

    var backgroundView: UIView?
    static let shared = HudViewTool()

    func groundShow(isCovered: Bool = false) {
        DispatchQueue.main.async { [self] in
            self.hide()
            let frame = CGRect(x: 0, y: 0, width: 78, height: 78)
            //Masking view
            let backGroundViewFrame = isCovered == false ? frame: UIScreen.main.bounds
            backgroundView = UIView(frame: backGroundViewFrame)
            if keyWindow == nil || backgroundView == nil {
                return
            }
            keyWindow?.addSubview(backgroundView!)
            backgroundView!.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
            }
            let hudView = UIView(frame: frame)
            hudView.layer.cornerRadius = 12
            hudView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8)
            backgroundView!.addSubview(hudView)
            hudView.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
            }
            let indicatorView = UIActivityIndicatorView(style: .large)
            indicatorView.frame = CGRect(x: 0, y: 0, width: 36, height: 36)
            indicatorView.startAnimating()
            hudView.addSubview(indicatorView)
            indicatorView.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
            }
            hudView.alpha = 0.0
            UIView.animate(withDuration: 0.2, animations: {
                hudView.alpha = 1
            })
        }
    }

    func show(isCovered: Bool = false) {
        DispatchQueue.main.async { [self] in
            self.hide()
            let frame = CGRect(x: 0, y: 0, width: 78, height: 78)
            //Masking view
            let backGroundViewFrame = isCovered == false ? frame: UIScreen.main.bounds
            backgroundView = UIView(frame: backGroundViewFrame)
            if keyWindow == nil || backgroundView == nil {
                return
            }
            keyWindow?.addSubview(backgroundView!)
            backgroundView?.center = keyWindow!.center
            let hudView = UIView(frame: frame)
            backgroundView!.addSubview(hudView)
            hudView.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
            }
            let indicatorView = UIActivityIndicatorView(style: .large)
            indicatorView.frame = CGRect(x: 21, y: 21, width: 36, height: 36)
            indicatorView.color = UIColor.black
            indicatorView.startAnimating()
            hudView.addSubview(indicatorView)
            indicatorView.snp.makeConstraints { (make) in
                make.center.equalToSuperview()
            }
            hudView.alpha = 0.0
            UIView.animate(withDuration: 0.2, animations: {
                hudView.alpha = 1
            })
        }
    }

    func hide() {
        backgroundView?.removeFromSuperview()
        backgroundView = nil
    }
}
