//
//  UINibExtension.swift
//  uq-global-ios-app-tw
//
//  Created by 李猷 on 2021/3/15.
//

import UIKit

extension UINib {

    // extend UINib.instantiate to avoid force type cast
    open func instantiate<View>(withOwner ownerOrNil: Any?,
                                options optionsOrNil: [UINib.OptionsKey: Any]? = nil,
                                viewType: View.Type = View.self
    ) -> [View] {
        return instantiate(
            withOwner: ownerOrNil,
            options: optionsOrNil
            // swiftlint:disable:next force_cast
        ) as! [View]
    }

}
