//  Copyright © 2020 Fast Retailing Co., Ltd. All rights reserved.
//

import UIKit

enum ModelToolError: Error {
    case message(String)
}

struct ModelEncoder {
    static public func encode<T>(model: T) throws -> Any? where T: Encodable {
        let jsonEncoder = JSONEncoder()
        jsonEncoder.dateEncodingStrategy = .secondsSince1970
        guard let data = try?jsonEncoder.encode(model) else {
            throw ModelToolError.message("transform to data failed.")
        }
        guard let json = getJsonDict(with: data) else {
            throw ModelToolError.message("transform to dictionary failed.")
        }
        return json
    }

    static public func getJsonDict(with data: Data) -> Any? {
        guard let json = try?JSONSerialization.jsonObject(with: data, options: .mutableContainers) else {
            return nil
        }
        return json
    }
}

struct ModelDecoder {
    static public func decode<T>(_ type: T.Type, param: [String: Any]) throws -> T where T: Decodable {
        guard let jsonData = self.getJsonData(with: param) else {
            throw ModelToolError.message("transform to data failed.")
        }
        let jsonDecoder = JSONDecoder()
        jsonDecoder.dateDecodingStrategy = .secondsSince1970
        guard let model = try? jsonDecoder.decode(type, from: jsonData) else {
            throw ModelToolError.message("transform to model failed.")
        }
        return model
    }

    static public func decode<T>(_ type: T.Type, paramsArray: [[String: Any]]) throws -> [T] where T: Decodable {
        var models: [T] = []
        for param in paramsArray {
            if let model = try?self.decode(type, param: param) {
                models.append(model)
            }
        }
        return models
    }

    static public func getJsonData(with param: Any) -> Data? {
        if !JSONSerialization.isValidJSONObject(param) {
            return nil
        }
        guard let data = try? JSONSerialization.data(withJSONObject: param, options: []) else {
            return nil
        }
        return data
    }
}

protocol CodableEnumeration: RawRepresentable, Codable where RawValue: Codable {
    static var defaultCase: Self { get }
}

extension CodableEnumeration {
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        do {
            let decoded = try container.decode(RawValue.self)
            self = Self.init(rawValue: decoded) ?? Self.defaultCase
        } catch {
            self = Self.defaultCase
        }
    }
}
