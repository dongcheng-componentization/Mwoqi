//
//  UICollectionView+SubView.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/17.
//

import Foundation
import UIKit

extension UICollectionView {

    // extend dequeueReusableCell to avoid force type cast
    open func dequeueReusableCell<Cell: UICollectionViewCell>(
        withReuseIdentifier identifier: String,
        for indexPath: IndexPath,
        cellType: Cell.Type = Cell.self
    ) -> Cell {
        // swiftlint:disable:next force_cast
        return dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! Cell
    }

    // extend dequeueReusableSupplementaryView to avoid force type cast
    open func dequeueReusableSupplementaryView<View: UICollectionReusableView>(
        ofKind elementKind: String,
        withReuseIdentifier identifier: String,
        for indexPath: IndexPath,
        viewType: View.Type = View.self
    ) -> View {
        return dequeueReusableSupplementaryView(
            ofKind: elementKind,
            withReuseIdentifier: identifier,
            // swiftlint:disable:next force_cast
            for: indexPath) as! View
    }
}
