//
//  UQToastView.swift
//  uq-global-ios-app
//
//  Created by 李猷 on 2021/4/8.
//

import Foundation
import UIKit

final class UQToastView: UIView {

    @IBOutlet weak var toastView: UIView!
    @IBOutlet weak var toastIconView: UIView!
    @IBOutlet weak var toastIcon: UIImageView!
    @IBOutlet weak var toastContentLabel: UILabel!

    @IBOutlet weak var toastIconViewHeightConstraint: NSLayoutConstraint!

    var isShowing: Bool = false
//    var duration: TimeInterval!
//    var superView: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()

        toastContentLabel.font = UIFont.systemFont(ofSize: 14)
        toastView.layer.masksToBounds = true
        toastView.layer.cornerRadius = 5.0
        toastView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMinXMinYCorner]
    }

}

extension UQToastView {

    /*! @param content: content of the toast.
        @param type: toast type, "success", "warn", "error", "text". The toast icon is not show when the type is "text".
     */
    @objc static func toastInit( content: String?, type: String ) -> UQToastView? {

        let toastView =  UINib(nibName: "UQToastView", bundle: nil)
            .instantiate(withOwner: self, options: nil, viewType: UQToastView.self).first!
        toastView.toastContentLabel.text = content ?? ""

        if type == "text" {
            toastView.toastIcon.isHidden = true
            toastView.toastIconViewHeightConstraint.constant = 0
        } else {
            toastView.toastIcon.image = UIImage(named: "toast_\(type)")
        }
    
        return toastView
    }

    static func toastTextView(content:String) {
        let toast = UQToastView.toastInit(content: content, type: "text")
        toast?.show(duration: 1,superView: UIApplication.shared.keyWindow ?? UIView())
    }
}

extension UQToastView {

    // dialog show
    @objc internal func show(duration: TimeInterval = 2, superView: UIView) {
        superView.addSubview(self)

        NSLayoutConstraint(
            item: self, attribute: .centerX, relatedBy: .equal, toItem: superView,
            attribute: .centerX, multiplier: 1, constant: 0 ).isActive = true
        NSLayoutConstraint(
            item: self, attribute: .centerY, relatedBy: .equal, toItem: superView,
            attribute: .centerY, multiplier: 1, constant: 0 ).isActive = true

        self.translatesAutoresizingMaskIntoConstraints = false

        toastView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.1, animations: {
            self.toastView.transform = .identity
        }, completion: { (_) in
            Timer.scheduledTimer(timeInterval: duration, target: self, selector: #selector(self.hide), userInfo: nil, repeats: false)
        })

        isShowing = true
    }

    // dialog hide
    @objc internal func hide() {
        UIView.animate(withDuration: 0.1, animations: {
            self.toastView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        }, completion: { (_) in
            self.removeFromSuperview()
            self.isShowing = false
        })
    }

}
