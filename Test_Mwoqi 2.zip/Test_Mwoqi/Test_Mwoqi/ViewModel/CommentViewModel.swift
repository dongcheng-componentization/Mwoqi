//
//  CommentViewModel.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/17.
//

import UIKit
import RxSwift
import RxCocoa
import Alamofire

class CommentViewModel: NSObject {
    public var like: Bool?
    public var id: Int = 1
    public var userId: Int = 1

    var rxCommentData: BehaviorSubject<[CommentDetailRepository]> = BehaviorSubject(value: [])
    let rxRequestError: PublishSubject<Error> = PublishSubject<Error>()
    var rxLikeStatus: BehaviorSubject<Bool> = BehaviorSubject(value: false)
    
    static let sharedSessionManager: Alamofire.SessionManager = {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 15//请求超时时间
        let manager = Alamofire.SessionManager(configuration: configuration)
        return manager
    }()
    
    public func loadData() {
        let headers: HTTPHeaders = [
            "Accept": "application/json"
        ]
        let url = String.init(format: "https://jsonplaceholder.typicode.com/post/\(id)/comments")
        HudViewTool.shared.groundShow(isCovered: false)

        CommentViewModel.sharedSessionManager.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: headers).responseJSON { [self] (response) in
            HudViewTool.shared.hide()
            guard response.result.error == nil else {
                self.rxRequestError.onNext(response.result.error as! Error)
                return
            }
            if response.result.isSuccess {
                var resultDict = try? JSONSerialization.jsonObject(with: response.data!, options: .mutableContainers) as? Array<[String: Any]>//
                let modelArr = (try?ModelDecoder.decode(CommentDetailRepository.self, paramsArray: resultDict ?? []))
                
                rxCommentData.onNext(modelArr ?? [])
            }
        }
    }
}
