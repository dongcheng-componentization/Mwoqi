//
//  FirstViewModel.swift
//  Test_Mwoqi
//
//  Created by 夏杭 on 2022/7/14.
//

import UIKit
import Alamofire
import RxSwift
import RxDataSources
import HandyJSON

class FirstViewModel: NSObject {
    var disposeBag = DisposeBag()
    var rxFirstData: BehaviorSubject<[SectionModel<String, FirstListRepository>]> = BehaviorSubject(value: [])
    let rxRequestError: PublishSubject<Error> = PublishSubject<Error>()
    var sectionModel: SectionModel<String, FirstListRepository>!
    var sortedBool: Bool = false
    var rxSortedStatus: BehaviorSubject<Bool> = BehaviorSubject(value: false)

    
    static let sharedSessionManager: Alamofire.SessionManager = {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 15//请求超时时间
        let manager = Alamofire.SessionManager(configuration: configuration)
        return manager
    }()
    
    public func loadData() {
        let headers: HTTPHeaders = [
            "Accept": "application/json"
        ]
        let url = "https://jsonplaceholder.typicode.com/posts"
        
        HudViewTool.shared.groundShow(isCovered: false)
        FirstViewModel.sharedSessionManager.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: headers).responseJSON { (response) in
            guard response.result.error == nil else {
                self.rxRequestError.onNext(response.result.error as! Error)
                return
            }
            if response.result.isSuccess {
                HudViewTool.shared.hide()
                var resultDict = try? JSONSerialization.jsonObject(with: response.data!, options: .mutableContainers) as? Array<[String: Any]>//
                var modelArr = (try?ModelDecoder.decode(FirstListRepository.self, paramsArray: resultDict ?? []))
               
                self.sectionModel = SectionModel.init(model: "", items: modelArr!)
                self.rxFirstData.onNext([self.sectionModel])
                
            }
        }
    }

    public func writeFirstData(_ indexPath: IndexPath) {
        self.sectionModel.items[indexPath.row].like = !(self.sectionModel.items[indexPath.row].like ?? false)
        self.rxFirstData.onNext([self.sectionModel])
    }
    
    public func sorted () {
        var sortedArrar = self.sectionModel.items
        sortedBool = !sortedBool
        rxSortedStatus.onNext(sortedBool)
        // 字母排序
        if sortedBool {
            let alphabeticalSort = sortedArrar.sorted(by: { $0.title! < $1.title! })
            self.sectionModel = SectionModel.init(model: "", items: alphabeticalSort)
        } else {
            let alphabeticalSort = sortedArrar.sorted(by: { $0.title! > $1.title! })
            self.sectionModel = SectionModel.init(model: "", items: alphabeticalSort)
        }
        self.rxFirstData.onNext([self.sectionModel])

        // 数字排序
//        self.sortedArrar.sort(by: { (rep0, rep1) -> Bool in
//            return rep0.userId ?? 1 > rep1.userId ?? 1 ? true : false
//        })
    }
}
